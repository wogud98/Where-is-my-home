package com.ssafy.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhereIsMyHomeDaejeon06KjhWcmApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhereIsMyHomeDaejeon06KjhWcmApplication.class, args);
	}

}
