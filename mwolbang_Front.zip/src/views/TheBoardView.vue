<script setup></script>

<template>
    <div class="container text-center mt-3">
        <router-view></router-view>
    </div>
</template>

<style>
mark.sky {
    background: linear-gradient(to top, #d7ff54 20%, transparent 30%);
}
</style>
