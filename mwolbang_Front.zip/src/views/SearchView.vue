<!-- Search 메인 페이지 -->
<script setup></script>

<template>
  <body>
    <div id="kakaoViewBox">
      <RouterView></RouterView>
    </div>
  </body>
</template>

<style scoped></style>
