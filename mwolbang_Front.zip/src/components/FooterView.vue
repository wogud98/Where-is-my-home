<script></script>

<template>
  <footer>
    <div>이용약관</div>
    <div>개인정보처리방침</div>
    <div>고객센터</div>
    <div>뭘방이야기</div>
  </footer>
</template>

<style scoped></style>
