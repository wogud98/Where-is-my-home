<script setup>
defineProps({ article: Object });
</script>

<template>
    <tr class="text-center">
        <th scope="row">{{ article.articleNo }}</th>
        <td class="text-start">
            <router-link
                :to="{
                    name: 'article-view',
                    params: { articleno: article.articleNo },
                }"
                class="article-title link-dark"
            >
                {{ article.subject }}
            </router-link>
        </td>
        <td>{{ article.userName }}({{ article.userId }})</td>
        <td>{{ article.hit }}</td>
        <td>{{ article.registerTime }}</td>
    </tr>
</template>

<style scoped>
a {
    text-decoration: none;
}
</style>
